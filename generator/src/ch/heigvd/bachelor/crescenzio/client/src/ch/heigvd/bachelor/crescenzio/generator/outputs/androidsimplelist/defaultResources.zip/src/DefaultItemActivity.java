import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import ch.heigvd.bachelor.crescenzio.androidsimplelist.DataItem;

public class DefaultItemActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Bundle data = getIntent().getExtras();
		DataItem item = (DataItem) data.getSerializable("item");
		
		LinearLayout layout = new LinearLayout(this);
		TextView name = new TextView(this);
		TextView description = new TextView(this);
		TextView date = new TextView(this);
		TextView icon = new TextView(this);
		
		name.setText(item.getName());
		date.setText(item.getData("Description"));
		description.setText(item.getData("Description"));
		icon.setText(item.getData("Icon"));
		
		layout.addView(name);
		layout.addView(description);
		layout.addView(date);
		layout.addView(icon);
		
		setContentView(layout);
	}
}