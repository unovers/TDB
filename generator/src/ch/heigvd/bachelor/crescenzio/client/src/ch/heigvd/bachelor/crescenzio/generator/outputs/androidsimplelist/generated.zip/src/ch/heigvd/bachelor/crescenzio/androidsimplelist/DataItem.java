package ch.heigvd.bachelor.crescenzio.androidsimplelist;

import java.io.Serializable;
import java.util.HashMap;


public class DataItem extends Item implements Serializable {

	private static final long serialVersionUID = 1L;
	private HashMap<String, String> datas;
	
	public DataItem(String name) {
		super(name);
		this.datas = new HashMap<String, String>();
	}

	public String getData(String name) {
		return datas.get(name);
	}
	
	public void setData(String key, String value){
		this.datas.put(key, value);
	}
}
