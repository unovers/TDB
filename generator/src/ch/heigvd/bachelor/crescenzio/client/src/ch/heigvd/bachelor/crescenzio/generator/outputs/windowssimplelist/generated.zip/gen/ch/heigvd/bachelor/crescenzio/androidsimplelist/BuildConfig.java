/** Automatically generated file. DO NOT MODIFY */
package ch.heigvd.bachelor.crescenzio.androidsimplelist;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}