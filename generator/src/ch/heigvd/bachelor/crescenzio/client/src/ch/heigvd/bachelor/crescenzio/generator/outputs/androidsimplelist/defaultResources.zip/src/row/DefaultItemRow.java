/*Application concept based on the work of Indrajit Khare y
found at http://logc.at/2011/10/10/handling-listviews-with-multiple-row-types/ y
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.


Developped for bachelor work by Crescenzio Fabio
Project : Projet example
Author : Fabio CRESCENZIO
Organisation : HEIG
*/
package com.package1.row;

import com.package1.R;

import ch.heigvd.bachelor.crescenzio.androidsimplelist.DataItem;
import ch.heigvd.bachelor.crescenzio.androidsimplelist.row.Row;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import ch.heigvd.bachelor.crescenzio.androidsimplelist.row.RowType;

public class DefaultItemRow implements Row {
    private final DataItem item;
    private final LayoutInflater inflater;

    public DefaultItemRow(LayoutInflater inflater, DataItem item) {
        this.item = item;
        this.inflater = inflater;
    }

    public View getView(View convertView) {
        ViewHolder holder;
        View view;
        if (convertView == null) {
            ViewGroup viewGroup = (ViewGroup)inflater.inflate(R.layout.default_row, null);
            holder = new ViewHolder((TextView)viewGroup.findViewById(R.id.title),
                    (TextView)viewGroup.findViewById(R.id.description));
            viewGroup.setTag(holder);
            view = viewGroup;
        } else {
            view = convertView;
            holder = (ViewHolder)convertView.getTag();
        }

        holder.descriptionView.setText(item.getData("__item_type"));
        holder.titleView.setText(item.getName());

        return view;
    }

    public int getViewType() {
        return RowType.DEFAULT_ROW.ordinal();
    }

    private static class ViewHolder {
        final TextView titleView;
        final TextView descriptionView;

        private ViewHolder(TextView titleView, TextView descriptionView) {
            this.titleView = titleView;
            this.descriptionView = descriptionView;
        }
    }
}
