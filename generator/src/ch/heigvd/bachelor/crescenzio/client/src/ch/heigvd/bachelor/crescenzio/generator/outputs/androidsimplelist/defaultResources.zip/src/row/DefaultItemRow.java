import ch.heigvd.bachelor.crescenzio.androidsimplelist.DataItem;
import ch.heigvd.bachelor.crescenzio.androidsimplelist.row.Row;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import ch.heigvd.bachelor.crescenzio.androidsimplelist.row.RowType;

public class DefaultItemRow implements Row {
    private final DataItem item;
    private final LayoutInflater inflater;

    public DefaultItemRow(LayoutInflater inflater, DataItem item) {
        this.item = item;
        this.inflater = inflater;
    }

    public View getView(View convertView) {
        ViewHolder holder;
        View view;
        if (convertView == null) {
            ViewGroup viewGroup = (ViewGroup)inflater.inflate(R.layout.default_row, null);
            holder = new ViewHolder((TextView)viewGroup.findViewById(R.id.title),
                    (TextView)viewGroup.findViewById(R.id.description));
            viewGroup.setTag(holder);
            view = viewGroup;
        } else {
            view = convertView;
            holder = (ViewHolder)convertView.getTag();
        }

        holder.descriptionView.setText(item.getData("Description"));
        holder.titleView.setText(item.getData("Name"));

        return view;
    }

    public int getViewType() {
        return RowType.DEFAULT_ROW.ordinal();
    }

    private static class ViewHolder {
        final TextView titleView;
        final TextView descriptionView;

        private ViewHolder(TextView titleView, TextView descriptionView) {
            this.titleView = titleView;
            this.descriptionView = descriptionView;
        }
    }
}
