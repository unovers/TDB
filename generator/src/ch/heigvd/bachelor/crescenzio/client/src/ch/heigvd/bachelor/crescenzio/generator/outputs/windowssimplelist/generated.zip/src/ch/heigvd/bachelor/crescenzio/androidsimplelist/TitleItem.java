package ch.heigvd.bachelor.crescenzio.androidsimplelist;

public class TitleItem extends Item {

	public TitleItem(String name) {
		super(name);
	}

}
