package ch.heigvd.bachelor.crescenzio.androidsimplelist.row;
//TODO : IMPORT packageName.r
import com.package1.R;

import ch.heigvd.bachelor.crescenzio.androidsimplelist.row.RowType;
import ch.heigvd.bachelor.crescenzio.androidsimplelist.Item;
import ch.heigvd.bachelor.crescenzio.androidsimplelist.row.Row;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class TitleRow implements Row {
    private final Item item;
    private final LayoutInflater inflater;

    public TitleRow(LayoutInflater inflater, Item item) {
        this.item = item;
        this.inflater = inflater;
    }

    public View getView(View convertView) {
        ViewHolder holder;
        View view;
        if (convertView == null) {
            ViewGroup viewGroup = (ViewGroup)inflater.inflate(R.layout.title_row, null);
            holder = new ViewHolder((TextView)viewGroup.findViewById(R.id.title));
            viewGroup.setTag(holder);
            view = viewGroup;
        } else {
            view = convertView;
            holder = (ViewHolder)convertView.getTag();
        }
        holder.titleView.setText(item.getName());

        return view;
    }

    public int getViewType() {
        return RowType.TITLE_ROW.ordinal();
    }

    private static class ViewHolder {
        final TextView titleView;

        private ViewHolder(TextView titleView) {
            this.titleView = titleView;
        }
    }
}
