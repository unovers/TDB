package ch.heigvd.bachelor.crescenzio.androidsimplelist;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.http.util.ByteArrayBuffer;
import org.json.JSONArray;
import org.json.JSONObject;

import android.util.Log;

public class DataManager {
	private String wsUrl;
	private String rootAppLocation;
	ArrayList<DataItem> items;

	private boolean init;
	private HashMap<String, ArrayList<DataItem>> sortedItems;

	public DataManager(String url, String rootAppLocation) {
		this.wsUrl = url;
		this.rootAppLocation = rootAppLocation;
		init = false;
		items = new ArrayList<DataItem>();
		sortedItems = new HashMap<String, ArrayList<DataItem>>();
	}

	/**
	 * SRC : http://stackoverflow.com/questions/5472226/how-to-save-file-from-
	 * website-to-sdcard
	 * http://www.helloandroid.com/tutorials/how-download-fileimage-url-your-device
	 * 
	 * @param DownloadUrl
	 * @param fileName
	 */
	public void DownloadFromUrl(String DownloadUrl, String dest) {

		try {

			File dir = new File(rootAppLocation);
			if (!dir.exists()) {
				dir.mkdirs();
			}
			URL url = new URL(DownloadUrl);
			File file = new File(dir, dest);
			if(file.exists())
				file.delete();
			
			long startTime = System.currentTimeMillis();

			/* Open a connection to that URL. */
			URLConnection ucon = url.openConnection();

			/*
			 * Define InputStreams to read from the URLConnection.
			 */
			InputStream is = ucon.getInputStream();
			BufferedInputStream bis = new BufferedInputStream(is);

			/*
			 * Read bytes to the Buffer until there is nothing more to read(-1).
			 */
			ByteArrayBuffer baf = new ByteArrayBuffer(5000);
			int current = 0;
			while ((current = bis.read()) != -1) {
				baf.append((byte) current);
			}

			/* Convert the Bytes read to a String. */
			file.createNewFile();
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(baf.toByteArray());
			fos.flush();
			fos.close();
		} catch (IOException e) {
			Log.d("DownloadManager", "Error: " + e);
		}

	}

	public void loadDatas() {
		if(!init){
			File jsonFile = new File(rootAppLocation + File.separator + "datas.json");
			if (!jsonFile.exists()){
				DownloadFromUrl(wsUrl, "/datas.json");
			}
			try {
				FileInputStream stream = new FileInputStream(rootAppLocation + "/datas.json");
				String jsonStr = null;
				try {
					FileChannel fc = stream.getChannel();
					MappedByteBuffer bb = fc.map(FileChannel.MapMode.READ_ONLY, 0,
							fc.size());
	
					jsonStr = Charset.defaultCharset().decode(bb).toString();
				} finally {
					stream.close();
				}
				JSONObject jsonObj = new JSONObject(jsonStr);
	
				JSONArray array = jsonObj.getJSONArray("items");
				for (int i = 0; i < array.length(); i++) {
					JSONObject itemObj = array.getJSONObject(i);
	
					DataItem dataItem = new DataItem(itemObj.getString("Name"));
					Iterator<?> keys = itemObj.keys();
	
					while (keys.hasNext()) {
						String key = (String) keys.next();
						dataItem.setData(key, itemObj.getString(key));
					}
					items.add(dataItem);

				}
	
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			sortedItems.put("DefaultOrder", items);
			init = true;
		}

	}

	public HashMap<String, ArrayList<DataItem>> getDatas() {
		return sortedItems;
	}

	public void sortDatas(String... args) {
		HashMap<String, ArrayList<DataItem>> sortedDatas = new HashMap<String, ArrayList<DataItem>>();
		sortedItems = null;
		// Boucle sur tous les elements
		for (int i = 0; i < items.size(); i++) {
			DataItem item = items.get(i);
			String title = "";
			for (int l = 0; l < args.length; l++) {
				String arg = args[l];
				title += item.getData(arg);
				if (l != args.length - 1)
					title += " ";
			}
			if (sortedDatas.get(title) == null) {
				sortedDatas.put(title, new ArrayList<DataItem>());
			}
			sortedDatas.get(title).add(item);
		}

		sortedItems = sortedDatas;
	}

}
