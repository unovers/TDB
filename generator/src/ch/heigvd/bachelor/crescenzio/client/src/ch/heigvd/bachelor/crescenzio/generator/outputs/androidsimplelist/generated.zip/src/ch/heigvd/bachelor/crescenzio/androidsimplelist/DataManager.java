package ch.heigvd.bachelor.crescenzio.androidsimplelist;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.http.util.ByteArrayBuffer;
import org.json.JSONArray;
import org.json.JSONObject;

import android.util.Log;

public class DataManager {
	private String wsUrl;
	private String rootAppLocation;
	ArrayList<DataItem> items;

	private final String locationJSONFile = "datas.json";
	private final String locationResourcesFiles = "resources";
	private HashMap<String, ArrayList<DataItem>> sortedItems;

	public DataManager(String url, String rootAppLocation) {
		this.wsUrl = url;
		this.rootAppLocation = rootAppLocation;
		items = new ArrayList<DataItem>();
		sortedItems = new HashMap<String, ArrayList<DataItem>>();
	}

	/**
	 * SRC : http://stackoverflow.com/questions/5472226/how-to-save-file-from-
	 * website-to-sdcard
	 * 
	 * @param DownloadUrl
	 * @param fileName
	 */
	public void DownloadFromUrl(String DownloadUrl, String fileName) {

		try {

			File dir = new File(rootAppLocation);
			if (dir.exists() == false) {
				dir.mkdirs();
			}

			URL url = new URL(DownloadUrl); // you can write here any link
			File file = new File(dir, fileName);

			long startTime = System.currentTimeMillis();
			Log.d("DownloadManager", "download begining");
			Log.d("DownloadManager", "download url:" + url);
			Log.d("DownloadManager", "downloaded file name:" + fileName);

			/* Open a connection to that URL. */
			URLConnection ucon = url.openConnection();

			/*
			 * Define InputStreams to read from the URLConnection.
			 */
			InputStream is = ucon.getInputStream();
			BufferedInputStream bis = new BufferedInputStream(is);

			/*
			 * Read bytes to the Buffer until there is nothing more to read(-1).
			 */
			ByteArrayBuffer baf = new ByteArrayBuffer(5000);
			int current = 0;
			while ((current = bis.read()) != -1) {
				baf.append((byte) current);
			}

			/* Convert the Bytes read to a String. */
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(baf.toByteArray());
			fos.flush();
			fos.close();
			Log.d("DownloadManager",
					"download ready in"
							+ ((System.currentTimeMillis() - startTime) / 1000)
							+ " sec");

		} catch (IOException e) {
			Log.d("DownloadManager", "Error: " + e);
		}

	}

	public void loadDatas() {

		File datasFolder = new File(rootAppLocation);
		File jsonFile = new File(datasFolder + File.separator + "datas.json");
		if (!datasFolder.exists() || !jsonFile.exists())
			DownloadFromUrl(wsUrl, "datas.json");
		try {
			FileInputStream stream = new FileInputStream(jsonFile);
			String jsonStr = null;
			try {
				FileChannel fc = stream.getChannel();
				MappedByteBuffer bb = fc.map(FileChannel.MapMode.READ_ONLY, 0,
						fc.size());

				jsonStr = Charset.defaultCharset().decode(bb).toString();
			} finally {
				stream.close();
			}
			JSONObject jsonObj = new JSONObject(jsonStr);

			JSONArray array = jsonObj.getJSONArray("datas");
			for (int i = 0; i < array.length(); i++) {
				JSONObject itemObj = array.getJSONObject(i);

				DataItem dataItem = new DataItem(itemObj.getString("name"));
				Iterator<?> keys = itemObj.keys();

				while (keys.hasNext()) {
					String key = (String) keys.next();
					dataItem.setData(key, itemObj.getString(key));
				}
				items.add(dataItem);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		sortedItems.put("DefaultOrder", items);

	}

	//
	// public void checkfolder(String folderName, JSONArray currentPos,
	// JSONArray compareArray, boolean addMode) throws JSONException{
	// for(int i = 0; i < compareArray.length();i++){
	// JSONObject content = compareArray.getJSONObject(i);
	// if(content.getString("resource_type").equals("folder") &&
	// content.getString("name").equals("folderName")){//trouv�
	// for(int j = 0; j < compareArray.length();i++){
	// JSONArray resources = compareArray.getString("resources");
	// if(content.getString("resource_type") == folderName){
	// checkFil
	// }
	// }
	//
	//
	// }
	//
	// }
	//
	// public void checkFile(String fileName, JSONArray compareArray, boolean
	// addMode) throws JSONException{
	//
	// }
	//
	// public void updateDatas() throws JSONException{
	// DownloadFromUrl(wsUrl, "newdatas.json");
	//
	// //Charge le contenu du fichier r�cuper�
	// String result = "";
	// String result2 = "";
	// JSONObject jObjectCurrentDatas = new JSONObject(result);
	// JSONObject jObjectNewDatas = new JSONObject(result2);
	// //Pour chaque ressource locale, verifie si elle doit �tre supprim�e ou
	// mise � jour
	// JSONArray jResourceCurrentDatas =
	// jObjectCurrentDatas.getJSONArray("resources");
	// JSONArray jResourceNewDatas = jObjectNewDatas.getJSONArray("resources");
	//
	// for(int i = 0; i<jResourceCurrentDatas.length();i++){
	// JSONObject resource = jResourceCurrentDatas.getJSONObject(i);
	// // Pulling items from the array
	// String resourceType = resource.getString("resource_type");
	// String resourceType = resource.getString("");
	//
	// if(resourceType.equals("folder")){
	// checkFolder(folderName, jResourceNewDatas)
	// }else{
	// boolean found = false;
	// for(int j = 0; j<jResourceNewDatas.length();j++){
	// JSONObject resourceCompare = jResourceNewDatas.getJSONObject(j);
	//
	// }
	// if(checkFile(fileName, jResourceNewDatas)){
	// //supprime le fichier
	// System.out.println("Delete");
	// }
	//
	// }
	// }
	// //Pour chaque ressource distante, verifie si elle doit �tre t�l�charg�e
	// for(int i = 0; i<jResourceNewDatas.length();i++){
	// boolean found = false;
	// for(int j = 0; j<jObjectCurrentDatas.length();j++){
	//
	// }
	// if(!found){
	// //telecharge le fichier
	// System.out.println("Download");
	// }
	// }
	//
	// //Ecrit le nouveau fichier
	//
	//
	// }

	public HashMap<String, ArrayList<DataItem>> getDatas() {
		return sortedItems;
	}

	public void sortDatas(String... args) {
		HashMap<String, ArrayList<DataItem>> sortedDatas = new HashMap<String, ArrayList<DataItem>>();
		sortedItems = null;
		// Boucle sur tous les elements
		for (int i = 0; i < items.size(); i++) {
			DataItem item = items.get(i);
			String title = "";
			for (int l = 0; l < args.length; l++) {
				String arg = args[l];
				title += item.getData(arg);
				if (l != args.length - 1)
					title += " ";
			}
			if (sortedDatas.get(title) == null) {
				sortedDatas.put(title, new ArrayList<DataItem>());
			}
			sortedDatas.get(title).add(item);
		}

		sortedItems = sortedDatas;
	}

}
